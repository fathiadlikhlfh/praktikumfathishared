package com.example.praktikumfathi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
